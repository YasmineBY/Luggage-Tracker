/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ltracker.hva;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javafx.collections.ObservableList;

import static javafx.scene.paint.Color.color;

import ltracker.hva.Controllers.RegisterLuggageController;
import ltracker.hva.classes.FoundLuggage;
import ltracker.hva.classes.TableViewData;
import ltracker.hva.database.MyJDBC;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.hamcrest.Matchers.equalToIgnoringWhiteSpace;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.notNullValue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Yasmine Ben Youb 500775493
 */
public class RegisterLuggageControllerTest extends RegisterLuggageController {

    public static String testValue;
    FoundLuggage luggage;

    public static String LostAndFoundID;
    public static String TimeFound;
    public static String AirportDeparture;
    public static String FlightNumber;
    public static String DateFound;
    public static String AirportArrival;
    public static String PassengerName;
    public static String PassengerCity;
    public static String LabelNumber;
    public static String TypeLuggage;
    public static String BrandLuggage;
    public static String Color;
    public static String SpecialCharacteristics;
    public static String[] storeData = new String[12];
    
    
       public static ObservableList<TableViewData> luggageData;

    
  
       
       
    @Before
    public void setup() {
    MyJDBC myJDBC = new MyJDBC("corendon");

    }
 

    @Test
    public void classIsInstanceOf() {
        setup();
        FoundLuggage luggage = new FoundLuggage();
        assertThat(luggage, instanceOf(FoundLuggage.class));
    }

    @Test
    public void testDatabaseLuggageSave() throws SQLException {
        setup();
        String assumedID = "029";
        //enter the data into the database
        FoundLuggage luggage = new FoundLuggage();
        MyJDBC myJDBC = new MyJDBC("corendon");
        LocalDate inputDate = LocalDate.of(2000, 01, 01);
        getSaveButton();
        getLostAndFoundID();
        luggage.setLostAndFoundID("029");
        luggage.setFlightNumber("flightNumTest001");
        luggage.setTimeFound("15:33");
        luggage.setAirportDeparture("hoorn");
        luggage.setFlightNumber("test001");
        luggage.setDateFound(inputDate);
        luggage.setAirportArrival("test001");
        luggage.setPassengerName("test001");
        luggage.setPassengerCity("test001");
        luggage.setLabelNumber("test001");
        luggage.setTypeLuggage("test001");
        luggage.setBrandLuggage("test001");
        luggage.setColor("test001");
        luggage.setSpecialCharacteristics("test001");

        luggage.insertFoundLuggage(myJDBC);

        ResultSet rs = myJDBC.executeResultSetQuery(
                "SELECT * FROM corendon.foundluggage WHERE lostAndFoundID =" + "029");

        while (rs.next()) {
            // add each item from the ResultSet to the ComboBox as a string
            System.out.println(rs.getString(2));
            System.out.println(rs.getString("lostAndFoundID"));
            testValue = rs.getString("lostAndFoundID");
        }

        assertThat(assumedID, equalToIgnoringCase(testValue));
    }

    @Test
    public void whiteSpaceTest() throws SQLException {


        FoundLuggage luggage = new FoundLuggage();
        MyJDBC myJDBC = new MyJDBC("corendon");
        LocalDate inputDate = LocalDate.of(2000, 01, 01);
        String assumedID = "  068  ";

        luggage.setLostAndFoundID("  068  ");
        luggage.setFlightNumber("flightNumTest001");
        luggage.setTimeFound("15:33");
        luggage.setAirportDeparture("hoorn");
        luggage.setDateFound(inputDate);
        luggage.setAirportArrival("test001");
        luggage.setPassengerName("test001");
        luggage.setPassengerCity("test001");
        luggage.setLabelNumber("test001");
        luggage.setTypeLuggage("test001");
        luggage.setBrandLuggage("test001");
        luggage.setColor("test001");
        luggage.setSpecialCharacteristics("test001");

        luggage.insertFoundLuggage(myJDBC);

        ResultSet rs = myJDBC.executeResultSetQuery(
                "SELECT * FROM corendon.foundluggage WHERE lostAndFoundID =" + "068");

        while (rs.next()) {
            // add each item from the ResultSet to the ComboBox as a string
            System.out.println(rs.getString(2));
            testValue = rs.getString("lostAndFoundID");
        }

        assertThat(assumedID, equalToIgnoringWhiteSpace(testValue));

    }

    @Test
    public void valueIsNotNullTest() throws SQLException {
        FoundLuggage luggage = new FoundLuggage();
        MyJDBC myJDBC = new MyJDBC("corendon");
        LocalDate inputDate = LocalDate.of(2000, 01, 01);
        getFlightNumber();

        ResultSet rs = myJDBC.executeResultSetQuery(
                "SELECT * FROM corendon.foundluggage WHERE lostAndFoundID =" + "068");
        while (rs.next()) {
            // add each item from the ResultSet to the ComboBox as a string
            System.out.println(rs.getString(2));
            testValue = rs.getString("FlightNumber");

            assertThat(testValue, notNullValue());
            assertNotNull(testValue);
        }
    }

    @Test
    public void confirmAllDataRetrieved() throws SQLException {
        FoundLuggage luggage = new FoundLuggage();
        MyJDBC myJDBC = new MyJDBC("corendon");
        LocalDate inputDate = LocalDate.of(2000, 01, 01);

        getTimeFound();
        getAirportArrival();
        getAirportDeparture();
        getDateFound();
        getPassengerName();
        getSpecialCharacteristics();
        getPassengerCity();
        getLabelNumber();
        getTypeLuggage();
        getBrandLuggage();
        getColor();
        getSpecialCharacteristics();
        ResultSet rs = myJDBC.executeResultSetQuery(
                "SELECT * FROM corendon.foundluggage WHERE lostAndFoundID =" + "029");
        while (rs.next()) {
            LostAndFoundID = rs.getString("LostAndFoundID");
            FlightNumber = rs.getString("FlightNumber");
            TimeFound = rs.getString("TimeFound");
            AirportDeparture = rs.getString("AirportDeparture");
            DateFound = rs.getString("DateFound");
            AirportArrival = rs.getString("AirportArrival");
            PassengerName = rs.getString("PassengerName");
            PassengerCity = rs.getString("PassengerCity");
            LabelNumber = rs.getString("LabelNumber");
            TypeLuggage = rs.getString("TypeLuggage");
            BrandLuggage = rs.getString("BrandLuggage");
            LabelNumber = rs.getString("LabelNumber");
            Color = rs.getString("LabelNumber");
            storeData[0] = LostAndFoundID;

        }

        assertEquals("029", LostAndFoundID);
        assertEquals("test001", FlightNumber);
        assertEquals("test001", AirportArrival);
        assertEquals("15:33", TimeFound);
        assertEquals("hoorn", AirportDeparture);
        assertEquals("test001", PassengerName);
        assertEquals("test001", PassengerCity);
        assertEquals("test001", LabelNumber);
        assertEquals("test001", TypeLuggage);
        assertEquals("test001", BrandLuggage);
        assertEquals("test001", LabelNumber);
        assertEquals("test001", Color);

    }

    @Test
    public void confirmMoreDataRetrieved() throws SQLException {

        FoundLuggage luggage = new FoundLuggage();
        MyJDBC myJDBC = new MyJDBC("corendon");
        LocalDate inputDate = LocalDate.of(2000, 01, 01);

        ResultSet rs = myJDBC.executeResultSetQuery(
                "SELECT * FROM corendon.foundluggage WHERE lostAndFoundID =" + "068");
        while (rs.next()) {
            LostAndFoundID = rs.getString("LostAndFoundID");
            FlightNumber = rs.getString("FlightNumber");
            TimeFound = rs.getString("TimeFound");
            AirportDeparture = rs.getString("AirportDeparture");
            DateFound = rs.getString("DateFound");
            AirportArrival = rs.getString("AirportArrival");
            PassengerName = rs.getString("PassengerName");
            PassengerCity = rs.getString("PassengerCity");
            TypeLuggage = rs.getString("TypeLuggage");
            BrandLuggage = rs.getString("BrandLuggage");
            LabelNumber = rs.getString("LabelNumber");
            Color = rs.getString("LabelNumber");

            storeData[0] = LostAndFoundID;
            storeData[1] = FlightNumber;
            storeData[2] = TimeFound;
            storeData[3] = AirportDeparture;
            storeData[4] = AirportArrival;
            storeData[5] = PassengerName;
            storeData[6] = PassengerCity;
            storeData[7] = LabelNumber;
            storeData[8] = Color;
            storeData[9] = BrandLuggage;
            storeData[10] = TypeLuggage;

        }

        String[] testArray = new String[12];
        testArray[0] = "  068  ";
        testArray[1] = "flightNumTest001";
        testArray[2] = "15:33";
        testArray[3] = "hoorn";
        testArray[4] = "test001";
        testArray[5] = "test001";
        testArray[6] = "test001";
        testArray[7] = "test001";
        testArray[8] = "test001";
        testArray[9] = "test001";
        testArray[10] = "test001";

        assertArrayEquals(testArray, storeData);
    }

    @Test
    public void testIntegerDataRetrieved() throws SQLException {

        FoundLuggage luggage = new FoundLuggage();
        MyJDBC myJDBC = new MyJDBC("corendon");
        LocalDate inputDate = LocalDate.of(2000, 01, 01);

        ResultSet rs = myJDBC.executeResultSetQuery(
                "SELECT * FROM corendon.foundluggage WHERE lostAndFoundID =" + "068");
        while (rs.next()) {
            LostAndFoundID = rs.getString("LostAndFoundID");
            FlightNumber = rs.getString("FlightNumber");
            TimeFound = rs.getString("TimeFound");
            AirportDeparture = rs.getString("AirportDeparture");
            DateFound = rs.getString("DateFound");
            AirportArrival = rs.getString("AirportArrival");
            PassengerName = rs.getString("PassengerName");
            PassengerCity = rs.getString("PassengerCity");
            TypeLuggage = rs.getString("TypeLuggage");
            BrandLuggage = rs.getString("BrandLuggage");
            LabelNumber = rs.getString("LabelNumber");
            Color = rs.getString("Color");

        }
        assertNotSame(FlightNumber, DateFound);
        assertNotSame(FlightNumber, LabelNumber);



    }
        


    

    @Test
    public void assertDataIsEqualTo() throws SQLException {
        FoundLuggage luggage = new FoundLuggage();
        MyJDBC myJDBC = new MyJDBC("corendon");
        LocalDate inputDate = LocalDate.of(2000, 01, 01);

        ResultSet rs = myJDBC.executeResultSetQuery(
                "SELECT * FROM corendon.foundluggage WHERE lostAndFoundID =" + "068");
        while (rs.next()) {
            LostAndFoundID = rs.getString("LostAndFoundID");
            FlightNumber = rs.getString("FlightNumber");
            TimeFound = rs.getString("TimeFound");
            AirportDeparture = rs.getString("AirportDeparture");
            DateFound = rs.getString("DateFound");
            AirportArrival = rs.getString("AirportArrival");
            PassengerName = rs.getString("PassengerName");
            PassengerCity = rs.getString("PassengerCity");
            TypeLuggage = rs.getString("TypeLuggage");
            BrandLuggage = rs.getString("BrandLuggage");
            LabelNumber = rs.getString("LabelNumber");
            Color = rs.getString("Color");

            assertThat(TypeLuggage, equalTo("test001"));
             assertNotSame(TypeLuggage, "-1");
             assertNotSame(LostAndFoundID, "-1");
             assertNotSame(TimeFound, "vijfuurdrieendertig");

        }
    }

    @Test
    public void minBoundaryValueTest() throws SQLException {
        setup();
        String assumedID = "029";
        //enter the data into the database
        FoundLuggage luggage = new FoundLuggage();
        MyJDBC myJDBC = new MyJDBC("corendon");
        LocalDate inputDate = LocalDate.of(0, 01, 01);


        luggage.setLostAndFoundID("0");
        luggage.setFlightNumber("a");
        luggage.setTimeFound("00:00");
        luggage.setAirportDeparture("a");
        luggage.setFlightNumber("0");
        luggage.setDateFound(inputDate);
        luggage.setAirportArrival("a");
        luggage.setPassengerName("a");
        luggage.setPassengerCity("a");
        luggage.setLabelNumber("0");
        luggage.setTypeLuggage("a");
        luggage.setBrandLuggage("a");
        luggage.setColor("a");
        luggage.setSpecialCharacteristics("a");

        luggage.insertFoundLuggage(myJDBC);

        ResultSet rs = myJDBC.executeResultSetQuery(
                "SELECT * FROM corendon.foundluggage WHERE lostAndFoundID =" + "029");

        while (rs.next()) {
            // add each item from the ResultSet to the ComboBox as a string
            System.out.println(rs.getString(2));
            System.out.println(rs.getString("lostAndFoundID"));
            testValue = rs.getString("lostAndFoundID");
        }

   

            assertThat(assumedID, equalToIgnoringCase(testValue));
            
                         assertNotSame(LostAndFoundID, "nullnulleen");
                         assertNotSame(Color, "vijf");

            
            
        }

        @Test
        public void maxBounderyTest() throws SQLException {

            setup();
            String assumedID = "3000";
            //enter the data into the database
            FoundLuggage luggage = new FoundLuggage();
            MyJDBC myJDBC = new MyJDBC("corendon");
            LocalDate inputDate = LocalDate.of(2019, 01, 02);
            getAge();
            luggage.setLostAndFoundID("3000");
            luggage.setFlightNumber("3000");
            luggage.setAirportDeparture("hoorn");
            luggage.setFlightNumber("3000");
            luggage.setDateFound(inputDate);
            luggage.setAirportArrival("Schagen");
            luggage.setPassengerName("a");
            luggage.setPassengerCity("Vijftrdiwotneskdiehdifrkejs");
            luggage.setLabelNumber("Vijftrdiwotneskdiehdifrkejt");
            luggage.setTypeLuggage("Vijftrdiwotneskdiehdifrkejl");
            luggage.setBrandLuggage("Vijftrdiwotneskdiehdifrkejh");
            luggage.setColor("Vijftrdiwotneskdiehdifrkejr");
            luggage.setSpecialCharacteristics("VijftrdiwotneskdiehdifrkejtVijftrdiwotneskdiehdifrkejtVijftrdiwotneskdiehdifrkejtVijftrdiwotneskdiehdifrkejt"
                    + "VijftrdiwotneskdiehdifrkejtVijftrdiwotneskdiehdifrkejt");

            luggage.insertFoundLuggage(myJDBC);

            ResultSet rs = myJDBC.executeResultSetQuery(
                    "SELECT * FROM corendon.foundluggage WHERE lostAndFoundID =" + "3000");

            while (rs.next()) {
                testValue = rs.getString("lostAndFoundID");
            }

            assertThat(assumedID, equalToIgnoringCase(testValue));
                    assertNotSame(FlightNumber, "Schagen");
                    assertNotSame(SpecialCharacteristics, "-24");

            
        }

        @After
        public void closeDataBase() throws SQLException {
         MyJDBC myJDBC = new MyJDBC("corendon");
         myJDBC.close();
        }
        

    }

